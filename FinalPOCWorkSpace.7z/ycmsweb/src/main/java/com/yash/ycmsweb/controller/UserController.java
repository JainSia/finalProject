package com.yash.ycmsweb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.yash.ycmscore.model.User;
import com.yash.ycmscore.service.UserService;

/**
 * this is the Controller that will handle the requests for the User related
 * resources
 * 
 * @author ishan.juneja
 *
 */
@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class UserController {

	/**
	 * this will be the bean which will give the methods of UserService to the
	 * controller
	 */
	@Autowired
	private UserService userService;

	/**
	 * this method will return the list of all the users to the front
	 * application in JSON format
	 */
	@RequestMapping(value = "/users", method = RequestMethod.GET)
	public List<User> getAllUsers() {
		return userService.list();
	}

	/**
	 * this method will add a user in the users database
	 */
	@RequestMapping(value = "/users", method = RequestMethod.POST)
	public void addUser(@ModelAttribute User user) {
		userService.add(user);
	}

	/**
	 * this method will update a user in the database
	 */
	@RequestMapping(value = "/users", method = RequestMethod.PUT)
	public void updateUser(@ModelAttribute User user) {
		userService.update(user);
	}

	/**
	 * this method will delete a user from the database
	 */
	@RequestMapping(value = "/users/{id}", method = RequestMethod.DELETE)
	public void deleteUser(@PathVariable int id) {
		userService.delete(id);
	}

}
