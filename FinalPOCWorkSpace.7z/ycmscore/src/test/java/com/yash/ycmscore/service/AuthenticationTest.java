package com.yash.ycmscore.service;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.yash.ycmscore.serviceimpl.CustomerServiceImpl;

public class AuthenticationTest {

	/**
	 * this is mock object of Customer service. 
	 * @Mock is used to imitate the real object your code is depends on.
	 */
	@Mock
	CustomerServiceImpl serviceImpl;
	
	/**
	 * @Before this method runs before each test execution. 
	 */
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}
	
	/**
	 * Tests that authentication fails if username is null
	 */
	 @Test
	    public void testNullUsername() {
	        assertFalse(serviceImpl.customerAuthentication(null, "password"));
	    }
	 
	 /**
	  * Tests that authentication fails if password is null
	  */
	 @Test
	    public void testNullPassword() {
	        assertFalse(serviceImpl.customerAuthentication("username", null));
	    }
	 
	 /**
	  * Tests that authentication fails if username & password is null
	  */
	 @Test
	    public void testNullUsernameAndPassword() {
	        assertFalse(serviceImpl.customerAuthentication(null, null));
	    }
	
	 /**
	  * Test that authentication is successful for valid username and password
	  */
	@Test
	public void test_authentication_with_valid_credentials() {

		
		when(serviceImpl.customerAuthentication(any(String.class),any(String.class))).thenReturn(true);
		assertThat(serviceImpl.customerAuthentication("username", "password"), is(true));
	}
	
	
	/*@Test(expected = InvalidCredential.class)
	public void test_authentication_with_invalid_credentials() {

		doThrow(InvalidCredential.class).when(serviceImpl).customerAuthentication(null, null);
		User user = new User();
		serviceImpl.customerAuthentication(null, null);

	}*/
}
