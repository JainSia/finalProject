package com.yash.ycmscore.service;

import static org.junit.Assert.*;

import javax.mail.Session;

import org.junit.Test;

import com.yash.ycmscore.serviceimpl.MailService;

public class MailServiceTest {

	@Test
	public void test_sendEmail_checkFor_session() {
		MailService mailService = new MailService();
		Session session = mailService.getMailSession();
		assertNotNull(session);
	}

	@Test(expected = AssertionError.class)
	public void test_SendEmail_With_Empty_RecipientsAddress() {
		MailService mailService = new MailService();
		boolean result = mailService.sendEmail("", "test", "#");
		assertTrue(result);
	}
	
	@Test(expected=AssertionError.class)
	public void test_SendEmail_With_Wrong_PortNumber() {
		MailService mailService = new MailService();
		boolean result = mailService.sendEmail("yash.khanwilkar@yash.com", "test", "#");
		assertTrue(result);
	}
	
	@Test(expected=AssertionError.class)
	public void test_SendEmail_With_Wrong_HostName() {
		MailService mailService = new MailService();
		boolean result = mailService.sendEmail("yash.khanwilkar@yash.com", "test", "#");
		assertTrue(result);
	}
	
	@Test
	public void test_sendEmail_DoesNot_SendEmail_ifCredentialsAreWrong() {
		MailService mailService = new MailService();
		boolean result = mailService.sendEmail("yash.khanwilkar@yash.com", "test", "#");
		assertTrue(result);
	}

}