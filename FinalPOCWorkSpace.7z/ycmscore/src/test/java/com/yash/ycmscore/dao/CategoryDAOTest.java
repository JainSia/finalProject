package com.yash.ycmscore.dao;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import com.yash.ycmscore.model.Category;

public class CategoryDAOTest {

	@Mock
	CategoryDAO categoryDAO;
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void test_category_insertion_return_true_on_success() {

		Category category= new Category();
		when(categoryDAO.insert(any(Category.class))).thenReturn(true);
		assertThat(categoryDAO.insert(category),is(true));

	}
	
	@Test
	public void test_category_insertion_return_false_on_failure() {

		Category category= new Category();
		when(categoryDAO.insert(any(Category.class))).thenReturn(false);
		assertThat(categoryDAO.insert(category),is(false));
	}
}
