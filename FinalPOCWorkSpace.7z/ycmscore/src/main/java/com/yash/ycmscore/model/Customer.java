package com.yash.ycmscore.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * this is the user POJO. this will be used as a data traveler between the
 * different layers of the application this will also work as an entity for
 * database(customers)
 * 
 * Date - 07/04/2018
 * 
 * @author chetan.magre
 * @Entity Every persistent POJO class is an entity and is declared using
 *         the @Entity annotation
 * @Table annotation allows you to specify the details of the table that will be
 *        used to persist the entity in the database.
 */
@Entity
@Table(name = "customers")
public class Customer {
	/**
	 * this will be the id of the current customer
	 * 
	 * @Id declares the identifier property of this entity
	 * @GeneratedValue can be used to define the identifier generation strategy
	 * @Column The column(s) used for a property mapping can be defined using
	 *         the @Column annotation
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int id;

	/**
	 * this will be the firstname of the name
	 */
	@Column(name = "firstName")
	private String firstName;

	/**
	 * this will be the surname of the user
	 */
	@Column(name = "lastName")
	private String lastName;

	public String getDomainName() {
		return domainName;
	}

	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * this will be the email of the current customer
	 * 
	 * @Column The column(s) used for a property mapping can be defined using
	 *         the @Column annotation
	 */
	@Column(name = "email")
	private String email;

	/**
	 * this will be the contact number of the user
	 */
	@Column(name = "contact")
	private String contact;

	/**
	 * this will be the domainName of the current customer
	 * 
	 * @Column The column(s) used for a property mapping can be defined using
	 *         the @Column annotation
	 */
	@Column(name = "domainName")
	private String domainName;
	/**
	 * this will be the password of the current customer which will not be saved
	 * in to database
	 * 
	 * @Transient This is used when you don’t want to persist the value in
	 *            database.
	 */
	@Transient
	private String password;

	/**
	 * this will be the address of the user
	 */
	@Column(name = "address")
	private String address;

	/**
	 * this will be country of the user
	 */
	@Column(name = "country")
	private String country;

	/**
	 * this will be state of the user
	 */
	@Column(name = "state")
	private String state;

	/**
	 * this will be city of the user
	 */
	@Column(name = "city")
	private String city;

	/**
	 * this will be zip code of the user
	 */
	@Column(name = "zip")
	private Integer zip;

	/**
	 * this is a default constructor
	 */
	public Customer() {
	}

	/**
	 * this will be a parameterized constructor for creation of the objects
	 * 
	 * @param id
	 * @param firstName
	 * @param lastName
	 * @param contact
	 * @param email
	 * @param address
	 * @param country
	 * @param state
	 * @param city
	 * @param zip
	 */
	public Customer(int id, String firstName, String lastName, String contact, String email, String address,
			String country, String state, String city, Integer zip) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.contact = contact;
		this.email = email;
		this.address = address;
		this.country = country;
		this.state = state;
		this.city = city;
		this.zip = zip;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Integer getZip() {
		return zip;
	}

	public void setZip(Integer zip) {
		this.zip = zip;
	}

}
