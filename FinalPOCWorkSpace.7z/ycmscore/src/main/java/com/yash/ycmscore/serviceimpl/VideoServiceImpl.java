package com.yash.ycmscore.serviceimpl;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.yash.ycmscore.dao.VideoDAO;
import com.yash.ycmscore.model.Video;
import com.yash.ycmscore.service.VideoService;

/**
 * This class implements all the methods present in VideoService interface<br>
 * <br>
 * 
 * Date - 13/04/2018
 * 
 * @author harmeet.saluja
 * @Service annotation is used in your service layer and annotates classes that
 *          perform service tasks
 */

@Service
public class VideoServiceImpl implements VideoService {

	Logger log = LoggerFactory.getLogger(this.getClass().getName());

	/**
	 * The rootLocation is represents the root path where all the uploaded files
	 * will be saved.
	 */
	private final Path rootLocation = Paths.get("C:\\Users\\yash.verma\\Downloads\\customerfront\\src\\assets\\videos");

	/**
	 * this is the videoDAO bean needed in service
	 * 
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	private VideoDAO videoDAO;

	/**
	 * This method saves the Video File at a particular location.
	 * 
	 * @author harmeet.saluja
	 * @param file
	 *            File that is to be saved at a given location
	 * @param title
	 *            unique title of the file that will be saved inside the
	 *            database
	 * @return true if the file is saved successfully, else returns false
	 */
	public boolean store(MultipartFile file, String title) {
		try {
			Files.copy(file.getInputStream(), this.rootLocation.resolve(file.getOriginalFilename()));
			Video videoToBeSaved = new Video();
			videoToBeSaved.setPath(file.getOriginalFilename());
			videoToBeSaved.setTitle(title);
			videoDAO.saveVideoDetails(videoToBeSaved);
			return true;
		} catch (Exception e) {
			log.error("Failed" + e);
			return false;
		}
	}

	/**
	 * This method will use the will call the method of the userDAO to get the
	 * list of videos.
	 * 
	 * @author harmeet.saluja
	 * @return the list of the videos
	 */
	public List<Video> videosList() {
		return videoDAO.videosList();
	}

}
