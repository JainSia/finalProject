package com.yash.ycmscore.exception;

public class InvalidCredential extends RuntimeException {

	public InvalidCredential(String msg) {
		super(msg);
	}

}
