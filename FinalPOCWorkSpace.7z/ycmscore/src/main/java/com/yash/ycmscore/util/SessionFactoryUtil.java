package com.yash.ycmscore.util;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
@PropertySource(value = "classpath:resource/${spring.profiles.active}.properties")
public class SessionFactoryUtil {

	
	/**
	 * this will be used to read the properties file in future this could be
	 * used to read the profile option from the arguments
	 * 
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	private Environment environment;
	
	
	public SessionFactory getSessionFactoryForPassedDB(String dbname){

		Configuration configuration = new Configuration();
		configuration.setProperty("hibernate.connection.url", environment.getProperty("customer.jdbc.url")+dbname);
		configuration.setProperty("hibernate.connection.username", environment.getProperty("jdbc.username"));
		configuration.setProperty("hibernate.connection.password", environment.getProperty("jdbc.password"));
		configuration.setProperty("dialect", "org.hibernate.dialect.MySQLDialect");
		configuration.setProperty("hibernate.hbm2ddl.auto", "update");
		configuration.setProperty("connection.driver_class",environment.getProperty("jdbc.drivername"));
		configuration.addAnnotatedClass(com.yash.ycmscore.model.Article.class);
		configuration.addAnnotatedClass(com.yash.ycmscore.model.Page.class);
		StandardServiceRegistryBuilder ssrb=new StandardServiceRegistryBuilder().applySettings(configuration.getProperties());
		return configuration.buildSessionFactory(ssrb.build());
	}
	
}
