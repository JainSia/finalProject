package com.yash.ycmscore.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * This is the Object Transfer class. This will work as a data traveler and will
 * be used to transfer the data from controller to DAO and from DAO to controller.
 * It has several field like id:int, title:String, alias:String, status:int
 * 
 * 
 * @Entity It is the annotation used to define the class as a Entity for database.
 * @author aakash.jangid
 * @version 0.0.1
 * @since 14 April, 2018
 *
 */
@Entity
public class Category {

	/**
	 * This is the id of the Category.
	 * 
	 * @Id This annotation is used to declare that it is the primary key of the Entity class (Table).
	 * @GeneratedValue This annotation is used to declare that its value will be auto-incremented.
	 */
	@Id
	@GeneratedValue
	private int id;
	
	/**
	 * This is the title of the Category
	 */
	private String title;
	
	/**
	 * This is the alias name of the Category.
	 */
	private String alias;
	
	/**
	 * This is the status of the Category,
	 * It can be 0-Published, 1-Unpublished,
	 */
	private int status;
	
	/**
	 * This is the trash status of the Category,
	 * It can be 0-UnTrash, 1-Trash,
	 */
	private int trash;
	
	/**
	 * This is the access status of the Category,
	 * It can be 0-Public, 1-Private,
	 */
	private int access;
	
	/**
	 * This is the archive status of the Category,
	 * It can be 0-Not-Archive, 1-Archive,
	 */
	private int archive;
	
	/**
	 * This is the description of the Category.
	 */
	private String description;
	
	/**
	 * this will be the parent category of the category
	 * 
	 * @Column The column(s) used for a property mapping can be defined using
	 *         the @Column annotation
	 */
	@Column(name = "parentCategory")
	private String parentCategory;
	
	/**
	 * this will be the language status of the category
	 * 
	 * @Column The column(s) used for a property mapping can be defined using
	 *         the @Column annotation
	 */
	@Column(name = "language")
	private String language;

	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getArchive() {
		return archive;
	}
	public void setArchive(int archive) {
		this.archive = archive;
	}
	public int getAccess() {
		return access;
	}
	public void setAccess(int access) {
		this.access = access;
	}
	public int getTrash() {
		return trash;
	}
	public void setTrash(int trash) {
		this.trash = trash;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAlias() {
		return alias;
	}
	public void setAlias(String alias) {
		this.alias = alias;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getParentCategory() {
		return parentCategory;
	}
	public void setParentCategory(String parentCategory) {
		this.parentCategory = parentCategory;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
}