package com.yash.ycmscore.configuration;

import java.util.Properties;

import org.hibernate.SessionFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBean;

import com.yash.ycmscore.model.Customer;
import com.yash.ycmscore.model.Page;
import com.yash.ycmscore.model.User;
import com.yash.ycmscore.model.Video;

/**
 * this class will be the core database configuration in the application it
 * reads the database properties from the jdbc.properties file placed in the
 * resources folder on classpath this class will have a method which creates and
 * returns a hibernate sessionFactory object on the basis of the configuration
 * provided
 * 
 * Date - 04/04/2018
 * 
 * @author ishan.juneja
 * @Configuration Annotating a class with the @Configuration indicates that the
 *                class can be used by the Spring IoC container as a source of
 *                bean definitions.
 * @ComponentScan annotation is used with @Configuration to tell Spring the
 *                packages to scan for annotated components.
 * @PropertySource is used to externalize your configuration to a properties
 *                 file
 */
@Configuration
@ComponentScan({ "com.yash.ycmscore.configuration" })
@ComponentScan(basePackages = "com.yash")
@PropertySource(value = "classpath:resource/${spring.profiles.active}.properties")
class ApplicationConfig {
	/**
	 * this will be used to read the properties file in future this could be
	 * used to read the profile option from the arguments
	 * 
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	private Environment environment;

	/**
	 * this method will give the session factory object
	 * 
	 * @author ishan.juneja
	 * @return sessionFactory object which will be used to get the hibernate
	 *         session instance
	 */
	@Bean
	public LocalSessionFactoryBean sessionFactory() {

		LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
		sessionFactory.setDataSource(dataSource());
		sessionFactory.setPackagesToScan(new String[] { "com.yash.ycmscore.model" });

		// add your POJO classes to this method seperated by comma
		sessionFactory.setAnnotatedClasses(User.class,Customer.class,Page.class,Video.class);
		sessionFactory.setHibernateProperties(hibernateProperties());
		return sessionFactory;

	}

	/**
	 * this method will read the properties file from the location provided in
	 * the @PropertySource tag above the class
	 * 
	 * @author ishan.juneja
	 * @return hibernate properties
	 */
	private Properties hibernateProperties() {

		Properties properties = new Properties();
		properties.put("hibernate.dialect", environment.getRequiredProperty("hibernate.dialect"));
		properties.put("hibernate.show_sql", environment.getRequiredProperty("hibernate.show_sql"));
		properties.put("hibernate.format_sql", environment.getRequiredProperty("hibernate.format_sql"));
		properties.put("hibernate.hbm2ddl.auto", "update");
		return properties;

	}

	/**
	 * this method will create the DataSource for the hibernate sessionFactory
	 * 
	 * @author ishan.juneja
	 * @return Datasource for which hibernate will provide connections
	 */
	@Bean
	public DriverManagerDataSource dataSource() {

		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setUrl(environment.getProperty("jdbc.url"));
		dataSource.setUsername(environment.getProperty("jdbc.username"));
		dataSource.setPassword(environment.getProperty("jdbc.password"));
		dataSource.setDriverClassName(environment.getProperty("jdbc.drivername"));
		return dataSource;

	}

	/**
	 * this method will give the hibernate transaction manager
	 * 
	 * @author ishan.juneja
	 * @param SessionFactory
	 *            for which session factory will hibernate maintain the
	 *            transaction
	 * @return TransactionManager for the Sessions of the SessionFactory passed
	 * @Bean is a method-level annotation and a direct analog of the XML <bean/>
	 *       element. When JavaConfig encounters such a method, it will execute
	 *       that method and register the return value as a bean within a
	 *       BeanFactory
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Bean
	@Autowired
	public HibernateTransactionManager transactionManager(SessionFactory s) {

		HibernateTransactionManager txManager = new HibernateTransactionManager();
		txManager.setSessionFactory(s);
		return txManager;

	}

}
