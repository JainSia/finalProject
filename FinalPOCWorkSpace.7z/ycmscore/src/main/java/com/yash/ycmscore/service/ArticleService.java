package com.yash.ycmscore.service;

import java.util.List;

import com.yash.ycmscore.model.Article;

public interface ArticleService {

	public String createNewArticle(Article article,String domain);
	
	public List<String> getAllArticles(String domain);
	
	public List<Article> getListOfArticles(Article article, String domain);

	public boolean changeStatusToTrashStatus(int id,String domain);
	
	public boolean changeStatusToUntrashStatus(int id,String domain);
	
	public boolean changeStatusToPublishStatus(int id,String domain);

	public boolean changeStatusToUnpublishStatus(int id,String domain);
	
	public boolean changeStatusToUnFeatured(int id,String domain);
	
	public boolean changeStatusToFeatured(int id,String domain);
	
	public int deleteArticle(int id,String domain);

	public List<Article> getAllUntrashedArticles(String domain);
}
