package com.yash.ycmscore.dao;

import java.util.List;

import org.w3c.dom.ls.LSInput;

import com.yash.ycmscore.model.Customer;
import com.yash.ycmscore.model.Page;

/**
 * this interface will have methods for handling customer related operations
 * such as creating a database for the customer
 * 
 * Date - 04/04/2018
 * 
 * @author ishan.juneja Functionalities provided:- 1.) insert a user 2.) create
 *         new database using domainName 3.) list all the databases
 *
 */
public interface CustomerDAO {

	/**
	 * this method will create a database with the name passed to it
	 * 
	 * @author ishan.juneja
	 * @param dbname
	 */
	public void createDatabase(String dbname);

	/**
	 * this method will return all dbnames
	 * 
	 * @author ishan.juneja
	 * @return list of all database names in mysql server
	 */
	public List<String> getAllDatabaseNames();

	/**
	 * this method will insert a new customer in the database which is passed to
	 * it
	 *
	 * @author chetan.magre
	 * @param customer
	 *            object will have details of new customer
	 * @return int value on successful or unsuccessful operation
	 */
	public int insert(Customer customer);

	/**
	 * this method will check that customer trying to register is new or
	 * Registered
	 * 
	 * @author chetan.magre
	 * @param email
	 *            email of current customer trying to register
	 * @return boolean value on basis of is customer already exist or not
	 */
	public Customer isCustomerExist(String email);
	
	/**
	 * This method will give the top five updates that are done on the application
	 * from the database.
	 * 
	 * @author yash.khanwilkar
	 * @return List of all the updates that are done on the application in string
	 * 			format.
	 */
	public List<String> getTopFiveUpdates();
	

	/**
	 * This method will save the static page information such as
	 * (pageName,url,domainName) on the domain's database
	 * 
	 * @param page
	 *            object will have details of page which will be stored in
	 *            database
	 * @return int value on successful or unsuccessful operation
	 * @author yash.verma
	 */
	public int savePageContent(Page page);

	/**
	 * This method will return the url of the html page by the given parameters
	 * 
	 * @param pageName
	 *            name of the page to be displayed
	 * @param domainName
	 *            name of the domain for which page to be displayed
	 * 
	 * @author shyam.patidar
	 * 
	 * @return String 'url' if success else return 'null'
	 * 
	 */
	public String getPageUrl(String pageName, String domainName);

	/**
	 * this will be used for getting the customer according to login name
	 * 
	 * Date :- 06/04/2018
	 * 
	 * @author nitesh.yadav
	 * @param loginname
	 * @return it will return the customer to the customer service interface
	 */
	public Customer getCustomer(String loginname);

	/**
	 * this will update the customer details in the customers table and will
	 * return the updated customer
	 * 
	 * Date :- 06/04/2018
	 * 
	 * @author nitesh.yadav
	 * @param customer
	 * @return it will return the updated customer
	 */
	public Customer update(Customer customer);
	
	/**
	 * this method is to get all the customers from the customer table with
	 * there details
	 * 
	 * @author chetan.magre
	 * @return customers list with there details from database
	 */
	public List<Customer> getAllCustomers();

	/**
	 * this method will update customer login detail each time customer logs in
	 * to YCMS such as date and time, whose email is provided as parameter
	 * 
	 * @author chetan.magre
	 * @param email
	 *            of current logged in customer
	 */
	public void updateCustomerLoginDateTime(String email);

}
