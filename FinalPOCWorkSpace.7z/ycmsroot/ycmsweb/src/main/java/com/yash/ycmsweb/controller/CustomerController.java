package com.yash.ycmsweb.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.yash.ycmscore.exception.InvalidCredential;
import com.yash.ycmscore.exception.PageUrlNotFoundException;
import com.yash.ycmscore.model.Customer;
import com.yash.ycmscore.model.Token;
import com.yash.ycmscore.service.CustomerService;

import io.jsonwebtoken.Claims;

/**
 * this is the Controller that will handle the requests for the Customer related
 * resources
 * 
 * Date - 04/04/2018
 * 
 * @author ishan.juneja
 *
 */
@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class CustomerController {
	/**
	 * this will be the bean, which will give the methods of CustomerService to
	 * the controller
	 * 
	 * @author chetan.magre
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	private CustomerService customerService;

	/**
	 * this method will return db not available if a database with the name
	 * provided is present in the mysql server
	 * 
	 * @author ishan.juneja
	 * @param dbname
	 * @return 'available' if the name is available or 'domain not available' if
	 *         dbname exists
	 */
	@RequestMapping(value = "/customers/getdb/{dbname}", method = RequestMethod.GET)
	@ResponseBody
	public String getDBAvailablity(@PathVariable String dbname) {

		List<String> dbnames = customerService.getListOfDomainName();
		for (String tempdbname : dbnames) {
			if (dbname.equals(tempdbname)) {
				return "domain Not Available";
			}
		}
		return "available";
	}

	/**
	 * this method will get customer registration details such as email password
	 * domainName and will return proper String message to acknowledge customer
	 * 
	 * @author chetan.magre
	 * @param customer
	 *            object obtained in the form of json which is mapped to
	 *            customer Object
	 * @return String Message according to customer registration like
	 *         Registration successful, Email or Password is Incorrect, Customer
	 *         Already Registered
	 */
	@RequestMapping(value = "/customers/register", method = RequestMethod.POST)
	@ResponseBody
	public String customerRegisteration(@RequestBody Customer customer) {
		return customerService.customerRegistration(customer);
	}

	/**
	 * This method will authenticate the customer based on the credentials
	 * provided.
	 * 
	 * @param customer
	 *            JSON object having the credentials
	 * @return true if customer is authenticated otherwise false
	 * 
	 * @author minerva.shrivastava
	 */
	@RequestMapping(value = "/customers/authenticate", method = RequestMethod.POST)
	public boolean authenticateUser(@RequestBody Customer customer, HttpServletResponse httpServletResponse) {
		if (customerService.customerAuthentication(customer.getEmail(), customer.getPassword())) {
			return true;
		} else {
			httpServletResponse.setHeader("Authorization", null);
			throw new InvalidCredential("invalid username or password");
		}
	}

	/**
	 * This method of controller will return the url of a html page from the
	 * database of the specific customer's domain and open the required html
	 * page according to the url else PageUrlNotFoundException occur. When
	 * PageUrlNotFoundException occur it will redirect customer to the error
	 * page.
	 * 
	 * @param pageName
	 *            name of the page to be displayed
	 * @param domainName
	 *            name of the domain for which page to be displayed
	 * 
	 * @author yash.verma
	 * 
	 * @return 'url' if it is available in the database or 'null' if not
	 *         available
	 */
	@RequestMapping(value = "/customers/{pageName}", method = RequestMethod.GET)
	public String getStaticPageUrl(@PathVariable String pageName, HttpServletRequest httpRequest) {
		String url = null;
		Token token = null;
		Claims claims = (Claims) httpRequest.getAttribute("claims");
		String tojson = claims.getSubject();
		ObjectMapper mapper = new ObjectMapper();
		try {
			token = mapper.readValue(tojson, Token.class);
			System.out.println(token.getEmail());
		} catch (Exception exception) {
			exception.printStackTrace();
		}

		Customer customer = customerService.isCustomerExist(token.getEmail());

		try {
			url = "http://localhost:8080/" + customerService.getPageUrl(pageName, customer.getDomainName());
		} catch (PageUrlNotFoundException e) {
			// logger.info(e.getMessage());
			// url = ERROR_PAGE;
		}
		String path = url.replace('/', '\\');
		System.out.println(url);
		return path;
	}

	/**
	 * this will handle the post request from the 4200 port and will return the
	 * customer details according to the email id
	 * 
	 * @author nitesh.yadav
	 * 
	 * @param customer
	 *            this contains the email id
	 * @return customer object will be returned containing the details of the
	 *         customer
	 */
	@RequestMapping(value = "/customers/getcustomer", method = RequestMethod.GET)
	public Customer getCustomer(HttpServletRequest httpRequest) {
		Token token = null;
		Claims claims = (Claims) httpRequest.getAttribute("claims");
		String tojson = claims.getSubject();
		ObjectMapper mapper = new ObjectMapper();
		try {
			token = mapper.readValue(tojson, Token.class);
			System.out.println(token.getEmail());
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		return customerService.getCustomer(token.getEmail());
	}

	/**
	 * this will update the customer profile using the customer received from
	 * the customer
	 * 
	 * @author nitesh.yadav
	 * 
	 * @param customer
	 * @return updated customer will be returned
	 */
	@RequestMapping(value = "/customers/update", method = RequestMethod.POST)
	public Customer updateCustomer(@RequestBody Customer customer) {
		return customerService.updateCustomer(customer);
	}

	/**
	 * this method will handle the request for getting list of customers and
	 * will return list of customers registered to YCMS
	 * 
	 * @author chetan.magre
	 * @return list of customers
	 */
	@RequestMapping(value = "/customers/listAll", method = RequestMethod.GET)
	public List<Customer> allRegisteredCustomers() {
		List<Customer>customers= customerService.getListOfAllCustomers();
		for (Customer customer : customers) {
			System.out.println("Customers :" + customer.getEmail() +"  "+ customer.getLastLoginDate());
		}
		return customers;
	}
	
	/**
	 * This method will provide the list of updates stored in database
	 * 
	 * @author yash.khanwilkar
	 * @return list of updates from database
	 */
	@RequestMapping(value="/updates", method=RequestMethod.GET)
	public List<String> getUpdates() {
		return customerService.getTopFiveUpdates();
	}

}