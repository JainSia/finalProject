package com.yash.ycmsweb.configuration;

import javax.servlet.Filter;
import javax.servlet.MultipartConfigElement;
import javax.servlet.ServletRegistration.Dynamic;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

import com.yash.ycmsweb.filter.SessionManager;
import com.yash.ycmsweb.filter.SimpleCORSFilter;

/**
 * this class will be the Web initializer of the application. it will configure
 * the application on the basis of the configurations provided in the
 * application
 * 
 * @author ishan.juneja
 *
 */
public class YCMSInitializer extends AbstractAnnotationConfigDispatcherServletInitializer {
	/**
	 * this method will give the list of all the configuration classes passed to
	 * it
	 * 
	 * @author ishan.juneja
	 */
	@Override
	protected Class<?>[] getRootConfigClasses() {
		return new Class[] { YCMSConfiguration.class };
	}

	/**
	 * this method will give the servlets configuration classes for the
	 * application
	 * 
	 * @author ishan.juneja
	 */
	@Override
	protected Class<?>[] getServletConfigClasses() {
		return null;
	}

	/**
	 * this method will set the servlet mappings in the application
	 * 
	 * @author ishan.juneja
	 */
	@Override
	protected String[] getServletMappings() {
		return new String[] { "/" };
	}

	@Override
	protected Filter[] getServletFilters() {
		return new Filter[] { new SimpleCORSFilter(), new SessionManager() };
	}

	/**
	 * This method is used to set the file parameters that will be uploaded
	 * 
	 * @author harmeet.saluja
	 */
	@Override
	protected void customizeRegistration(Dynamic registration) {
		/**
		 * Parameters-: <br>
		 * location - the directory location where files will be stored. <br>
		 * maxFileSize - the maximum size allowed for uploaded files <br>
		 * maxRequestSize - the maximum size allowed for multipart/form-data
		 * requests <br>
		 * fileSizeThreshold - the size threshold after which files will be
		 * written to disk
		 */
		MultipartConfigElement multipartConfig = new MultipartConfigElement("D:/", 1048576000, 10485760000L, 0);
		registration.setMultipartConfig(multipartConfig);
	}

}
