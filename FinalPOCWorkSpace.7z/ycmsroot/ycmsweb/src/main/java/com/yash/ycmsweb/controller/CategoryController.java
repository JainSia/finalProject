package com.yash.ycmsweb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.yash.ycmscore.model.Category;
import com.yash.ycmscore.service.CategoryService;

/**
 * this is the Controller that will handle the requests for the Category related
 * resources
 * 
 * @author aakash.jangid
 *
 */
@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class CategoryController {

	/**
	 * this will be the bean which will give the methods of CategoryService to the
	 * controller
	 */
	@Autowired
	private CategoryService categoryService;

	/**
	 * this method will return the list of all the categories to the front
	 * application in JSON format
	 */
	@RequestMapping(value="/categories/{trashStatus}", method=RequestMethod.GET)
	public List<Category> getAllCategories(@PathVariable int trashStatus) {
		return categoryService.getAllCategories(trashStatus);
	}

	/**
	 * This method will change the status of the category whose id is being passed
	 * as the parameter in the URL.
	 * 
	 * @param id This is the identity of that category.
	 * @return true - if it changes the status successfully else it will return false.
	 */
	@RequestMapping(value = "/categories/trash/{id}", method = RequestMethod.GET)
	public boolean changeTrashStatus(@PathVariable int id) {
		return categoryService.changeTrashStatus(id);
	}

}