package com.yash.ycmscore.daoimpl;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.yash.ycmscore.dao.ArticleDAO;
import com.yash.ycmscore.model.Article;
import com.yash.ycmscore.util.SessionFactoryUtil;

@Repository
public class ArticleDAOImpl implements ArticleDAO {

	/**
	 * the sessionFactory which will give a session.
	 * 
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	private SessionFactoryUtil sessionFactoryUtil;


	public String createNewArticle(Article article,String domain) {
		article.setDatecreated(new Date(new java.util.Date().getTime()));
		SessionFactory factory=sessionFactoryUtil.getSessionFactoryForPassedDB(domain);
		Session session= factory.openSession();
		session.beginTransaction();
		session.saveOrUpdate(article);
		session.getTransaction().commit();
		session.close();
		factory.close();
		return "article saved";
	}
	
	public List<String> getAllArticles(String domain){
		List<String> articles=new ArrayList<String>();
		final SessionFactory factory=sessionFactoryUtil.getSessionFactoryForPassedDB(domain);
		Session session=factory.openSession();
		session.beginTransaction();
		Criteria criteria=session.createCriteria(Article.class);
		articles=criteria.setProjection(Projections.property("title")).list();
		session.getTransaction().commit();
		session.close();
		factory.close();
		return articles;
	}

}
