package com.yash.ycmscore.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Transient;

/**
 * this is the article POJO and will be used as the data traveler for Article in
 * the Application
 * 
 * @author ishan.juneja
 *
 */
@Entity
public class Article {

	@Id
	@GeneratedValue
	private int id;
	private String title;
	private String alias;
	
	@Transient
	private String htmlContent;
	private String featured;
	private String status;
	private String category;
	private String access;
	private String language;
	private String tags;
	private String author;
	private Date datecreated;
	private int hits;
	private String trash;

	public Article(){
		
	}

	public Article(int id, String title, String alias, String htmlContent, String featured, String status,
			String category, String access, String language, String tags, String author, Date datecreated, int hits,
			String trash) {
		super();
		this.id = id;
		this.title = title;
		this.alias = alias;
		this.htmlContent = htmlContent;
		this.featured = featured;
		this.status = status;
		this.category = category;
		this.access = access;
		this.language = language;
		this.tags = tags;
		this.author = author;
		this.datecreated = datecreated;
		this.hits = hits;
		this.trash = trash;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public String getHtmlContent() {
		return htmlContent;
	}

	public void setHtmlContent(String htmlContent) {
		this.htmlContent = htmlContent;
	}

	public String getFeatured() {
		return featured;
	}

	public void setFeatured(String featured) {
		this.featured = featured;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getAccess() {
		return access;
	}

	public void setAccess(String access) {
		this.access = access;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getTags() {
		return tags;
	}

	public void setTags(String tags) {
		this.tags = tags;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public Date getDatecreated() {
		return datecreated;
	}

	public void setDatecreated(Date datecreated) {
		this.datecreated = datecreated;
	}

	public int getHits() {
		return hits;
	}

	public void setHits(int hits) {
		this.hits = hits;
	}

	public String getTrash() {
		return trash;
	}

	public void setTrash(String trash) {
		this.trash = trash;
	}
	
	

}
