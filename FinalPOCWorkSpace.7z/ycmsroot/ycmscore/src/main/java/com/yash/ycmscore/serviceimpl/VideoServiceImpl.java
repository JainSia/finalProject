package com.yash.ycmscore.serviceimpl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.yash.ycmscore.dao.VideoDAO;
import com.yash.ycmscore.model.Video;
import com.yash.ycmscore.service.VideoService;

/**
 * This class implements all the methods present in VideoService interface<br>
 * <br>
 * 
 * Date - 13/04/2018
 * 
 * @author harmeet.saluja
 * @Service annotation is used in your service layer and annotates classes that
 *          perform service tasks
 */

@Service
public class VideoServiceImpl implements VideoService {

	Logger log = Logger.getLogger(this.getClass().getName());

	/**
	 * The rootLocation represents the root path where all the uploaded files
	 * will be saved.
	 */
	private Path rootLocation = null;

	/**
	 * The parentDirectory represents the location from where the application
	 * will search for the required Angular application
	 */
	private File parentDirectory = new File("D:\\");

	/**
	 * The path where all the videos will be stored
	 */
	private final String cliVideosPath = "src\\assets\\videos";

	/**
	 * this is the videoDAO bean needed in service
	 * 
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	private VideoDAO videoDAO;

	/**
	 * This method finds the directory where the videos are to be stored
	 * 
	 * @author harmeet.saluja
	 * @param parentDirectory
	 *            from where the application will start searching for the folder
	 *            where the videos are to be stored
	 */
	private void findDirectory(File parentDirectory) {
		File fileToFind = new File("YCMS-cli");
		File[] files = parentDirectory.listFiles();
		if (files != null) {
			findFile: for (File file : files) {
				if (file.getName().equals(fileToFind.getName())) {
					try {
						Files.createDirectory(Paths.get(file.getAbsolutePath(), this.cliVideosPath));
					} catch (IOException e) {
						log.error(e.getMessage());
					}
					this.rootLocation = Paths.get(file.getAbsolutePath(), this.cliVideosPath);
					break findFile;
				} else if (file.isFile())
					continue;
				else if (file.isDirectory() && file.getParent().equals("D:\\")) {
					findDirectory(file);
				}
			}
		}
	}

	/**
	 * This method saves the Video File at a particular location.
	 * 
	 * @author harmeet.saluja
	 * @param file
	 *            File that is to be saved at a given location
	 * @param title
	 *            unique title of the file that will be saved inside the
	 *            database
	 * @return true if the file is saved successfully, else returns false
	 */
	public boolean store(MultipartFile file, String title) {
		findDirectory(this.parentDirectory);
		try {
			Files.copy(file.getInputStream(), this.rootLocation.resolve(file.getOriginalFilename()));
			Video videoToBeSaved = new Video();
			videoToBeSaved.setPath(file.getOriginalFilename());
			videoToBeSaved.setTitle(title);
			videoDAO.saveVideoDetails(videoToBeSaved);
			log.info("Video Details Saved");
			return true;
		} catch (Exception e) {
			log.error("Failed" + e.getMessage());
			return false;
		}
	}

	/**
	 * This method will use the will call the method of the userDAO to get the
	 * list of videos.
	 * 
	 * @author harmeet.saluja
	 * @return the list of the videos
	 */
	public List<Video> videosList() {
		return videoDAO.videosList();
	}

}
