package com.yash.ycmscore.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.ycmscore.dao.CategoryDAO;
import com.yash.ycmscore.model.Category;
import com.yash.ycmscore.service.CategoryService;

/**
 * This class is the implementation of the CategoryService Interface.
 * This class will have methods for handling category related services such as
 * listing all the categories.
 * 
 * 
 * @version 0.0.1
 * 
 * @since 14 April, 2018
 * 
 * @author aakash.jangid
 *
 *@Service annotation is used in your service layer and annotates classes that
 *          perform service tasks
 */
@Service
public class CategoryServiceImpl implements CategoryService {

	/**
	 * this is the customerDAO bean needed in service
	 * 
	 * @author aakash.jangid
	 * @Autowired annotation is auto wire the bean by matching data type.
	 */
	@Autowired
	private CategoryDAO categoryDAO;

	/**
	 * This method will fetch all the categories from the database and will be
	 * called whenever the list of the categories is required.
	 * 
	 * @author aakash.jangid
	 * 
	 * @return List<Category> - This method will return a List of Category.
	 */
	public List<Category> getAllCategories(int trashStatus) {
		return categoryDAO.getAllCategories(trashStatus);
	}

	/**
	 * This method will change the trash status of the category. It will fetch the
	 * particular category with the help of the id passed as a parameter and then it
	 * will update the trash status of the category.
	 * 
	 * @param id:int it is the id of the category by which the category will be fetched.
	 * 
	 * @author aakash.jangid
	 * 
	 * @return boolean it will return true if the status has been updated
	 *         successfully else it will return false.
	 */
	public boolean changeTrashStatus(int id) {
		return categoryDAO.changeTrashStatus(id);
	}

}