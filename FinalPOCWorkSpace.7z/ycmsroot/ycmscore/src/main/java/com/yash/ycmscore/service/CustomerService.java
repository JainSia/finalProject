package com.yash.ycmscore.service;

import java.io.File;
import java.util.List;

import com.yash.ycmscore.model.Customer;

/**
 * this is the service interface for Customer related operations such as create,
 * list customers, update and delete a Customer
 * 
 * Date - 07/04/2018
 * 
 * @author chetan.magre Functionalities provided 1.) Customer Registration 2.)
 *         getting list of all database
 * 
 */
public interface CustomerService {

	/**
	 * this method will register a new customer
	 * 
	 * @author chetan.magre
	 * @param customer
	 * @return String value for successful and unsuccessful registration
	 */
	public String customerRegistration(Customer customer);

	/**
	 * this method will list all the domainNames
	 * 
	 * @author chetan.magre
	 * @return list of domianNames
	 */
	public List<String> getListOfDomainName();

	/**
	 * This method will authenticate the customer based on the credentials
	 * provided
	 * 
	 * @param Yash
	 *            emailId of customer
	 * @param Yash
	 *            password of customer
	 * @return true if customer is authenticated otherwise false
	 * 
	 * @author minerva.shrivastava
	 */
	public boolean customerAuthentication(String email, String password);
	/**
	 * This method will create the folder and file structure by the name of the
	 * Domain and the path where it should be create
	 * 
	 * @param domainName
	 *            name of the domain where the files to be created
	 * @param path
	 *            where the files to be created
	 * @return boolean value on successful or unsuccessful operation
	 * 
	 * @author yash.verma
	 */
	public boolean createFiles(String domainName, String path);

	/**
	 * This method will copy the content of one file to another file
	 * 
	 * @param staticindex
	 * @param indexfile
	 * @return boolean value on successful or unsuccessful operation
	 * @author yash.verma
	 */
	public boolean copyContent(File staticindex, File indexfile);

	/**
	 * This service method will return the url of a static page in the form of
	 * string by provided parameters- pageName and domainName
	 * 
	 * @param pageName
	 *            name of the page to be displayed
	 * @param domainName
	 *            name of the domain for which page to be displayed
	 * 
	 * @author shyam.patidar
	 * 
	 * @return String 'url' if success else return 'null'
	 */
	public String getPageUrl(String pageName, String domainName);

	/**
	 * this method is to check whether or not customer is in the database. or is
	 * registered or not
	 * 
	 * @author chetan.magre
	 * @param email
	 *            address of customer
	 * @return customer with its details from database
	 */
	public Customer isCustomerExist(String email);

	/**
	 * this will be used for getting the customer according to login name
	 * 
	 * Date :- 09/04/2018
	 * 
	 * @author nitesh.yadav
	 * @param loginname
	 * @return it will return the customer to the customerController
	 */
	public Customer getCustomer(String loginame);

	/**
	 * this will update the customer details in the customers table and will
	 * return the updated customer
	 * 
	 * Date :- 09/04/2018
	 * 
	 * @author nitesh.yadav
	 * @param customer
	 * @return it will return the updated customer to the customerController
	 */
	public Customer updateCustomer(Customer customer);

	/**
	 * this method will get all the customers registered and return list
	 * 
	 * @author chetan.magre
	 * @return list of customers
	 */
	public List<Customer> getListOfAllCustomers();

	/**
	 * This method will provide the top five updates that are performed on the 
	 * application and stored in the database
	 * 
	 * @author yash.khanwilkar 
	 * @return List of updates in String format
	 */
	public List<String> getTopFiveUpdates();
}
